#ifndef __Car_Init_H__
#define __Car_Init_H__


extern void Car_Init(void);


#endif